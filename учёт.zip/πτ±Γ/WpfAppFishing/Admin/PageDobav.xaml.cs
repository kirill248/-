﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppFishing.ApplicationData;

namespace WpfAppFishing.Admin
{
    /// <summary>
    /// Логика взаимодействия для PageDobav.xaml
    /// </summary>
    public partial class PageDobav : Page
    {
        int IdPic = 0;
        private Product portfolio1 = new Product();
        private Product productfield = new Product();
        public PageDobav(Product selectedProduct)
        {
            InitializeComponent();
           
            cbmbx4.SelectedValuePath = "MeasureID";
            cbmbx4.DisplayMemberPath = "MeasureName";
            cbmbx4.ItemsSource = AppConnect.modelOdb.Measure.ToList();
           
            if (selectedProduct != null)
            {
                productfield = selectedProduct;
            }
            DataContext = productfield;
        }

        private void btnNaz_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.framelMain.GoBack();
        }

        private void cbmbx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.framelMain.GoBack();
        }
       

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Class1AddEdit.Id == 1)
                {
                   
                    Product productObj = new Product()
                    {
                        ProductName = txtbx.Text,
                        ProductQuantityInStock = Convert.ToInt32(txtbx1.Text),
                        
                     
                        ProductPhoto = portfolio1.ProductPhoto,
                        ProductArticleNumber = txtbx7.Text,
                        ProductDiscountAmount = Convert.ToInt32(txtbx8.Text),

                    };
                    AppConnect.modelOdb.Product.Add(productObj);
                }
                    if (IdPic > 0)
                    {
                        productfield.ProductPhoto = portfolio1.ProductPhoto;
                    }
                    AppConnect.modelOdb.SaveChanges();
                    //MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    AppFrame.framelMain.GoBack();

                
            }
            catch (Exception ex)
            {

                MessageBox.Show("Ошибка:" + ex.Message.ToString(), "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void btn4_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                var openDialog = new OpenFileDialog();
                openDialog.Filter = "Image files (*.BMP, *.JPG, *.GIF, *.TIF, *.PNG, *.ICO, *.EMF, *.WMF) | *.bmp; *.jpg; " +
                    "*.gif; *.tif; *.png; *.ico; *.emf; *.wmf";
                openDialog.ShowDialog();
                if (openDialog.CheckFileExists && openDialog.FileName.Length > 0)
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(openDialog.FileName);
                    bitmap.DecodePixelWidth = 250;
                    bitmap.EndInit();              
                    portfolio1.ProductPhoto = File.ReadAllBytes(openDialog.FileName);
                    IdPic = 1;
                }
            }
            catch 
            {

                MessageBox.Show("Ошибка загрузки изображения", "Ошибка");
            }
        }
    }
}

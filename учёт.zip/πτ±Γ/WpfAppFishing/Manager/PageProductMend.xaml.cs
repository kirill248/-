﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppFishing.ApplicationData;

namespace WpfAppFishing.Manager
{
    /// <summary>
    /// Логика взаимодействия для PageProductMend.xaml
    /// </summary>
    public partial class PageProductMend : Page
    {
        public PageProductMend()
        {
            InitializeComponent();
            listview.ItemsSource = AppConnect.modelOdb.Product.ToList();
            var count_col = listview.Items.Count; //счет кол-во данных в лист вью
           


            CMB_ProductManufacturer.SelectedValuePath = "ID_ProductManufacturer";
            CMB_ProductManufacturer.DisplayMemberPath = "NameManufacturer";
            CMB_ProductManufacturer.ItemsSource = AppConnect.modelOdb.Manufacturer.ToList();

        }
        public void Filtracia()//брала метод из презентации 3 курса
        {
            var SerachList = AppConnect.modelOdb.Product.ToList();
            int group = Convert.ToInt32(CMB_ProductManufacturer.SelectedValue);

            if (CMB_ProductManufacturer.SelectedIndex > -1)
            {
                nameProduct.Text = group.ToString();
                SerachList = SerachList.Where(x => x.ProductManufacturer == group).ToList();
            }
            if (nameProduct.Text != "")
            {
                SerachList = SerachList.Where(x => x.ProductName.ToLower().Contains(nameProduct.Text.ToLower())).ToList();
            }

            listview.ItemsSource = SerachList.ToList();

        }
        

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.framelMain.GoBack();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            
                if ((sender as RadioButton).Tag.ToString() == "1")
                {
                    listview.ItemsSource = AppConnect.modelOdb.Product.OrderBy(x => x.ProductCost.ToString()).ToList();

                }
                else if ((sender as RadioButton).Tag.ToString() == "2")
                {
                    listview.ItemsSource = AppConnect.modelOdb.Product.OrderByDescending(x => x.ProductCost.ToString()).ToList();
                }
            }

       

        private void CMB_ProductManufacturer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
                int number = Convert.ToInt32(CMB_ProductManufacturer.SelectedValue);
                Filtracia();


                var count_col = listview.Items.Count;
              
            }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            
                listview.ItemsSource = AppConnect.modelOdb.Product.ToList();

                var count_col = listview.Items.Count;
               
            
        }

        private void nameProduct_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (nameProduct.Text != "")
            {
                Filtracia();


                var count_col = listview.Items.Count;
               
            }
            else
            {
                listview.ItemsSource = AppConnect.modelOdb.Product.ToList();


                var count_col = listview.Items.Count;
               
            }
        }
    }
 }
 


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppFishing.ApplicationData
{
    class Class1AddEdit
    {
        public static int Id { get; set; }
    }
}

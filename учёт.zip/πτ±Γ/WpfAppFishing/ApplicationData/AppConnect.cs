﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppFishing.ApplicationData
{
    class AppConnect
    {
        public static рыбалкаEntities4 modelOdb;
    }
}
